// npm i bcryptjs jsonwebtoken validator nodemailer cookie parser body-parser
// password convert into the hash then store it into the mongodb
//jsonwebtoken use to generate the token
//validator validate email filed to need to valid email
//nodemailer send mail
//cookie parser store jwt token
