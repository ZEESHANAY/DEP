function signup() {
    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    // Perform validation or send signup request here
    // For now, we just show an alert
    alert('Signup button pressed.\nUsername: ' + newUsername + '\nPassword: ' + newPassword);

    // Hide signup form and show login form
    document.getElementById('signupContainer').classList.add('hidden');
    document.getElementById('loginContainer').classList.remove('hidden');
}

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Perform validation or send login request here
    // For now, we just show an alert
    alert('Login button pressed.\nUsername: ' + username + '\nPassword: ' + password);
}
